import json,os,pathlib,subprocess,sys,datetime
root=pathlib.Path('/home/chabking/workspace/ani-network-service-runs/base-diag-20260917T1437')
source=root/sys.argv[1];label=sys.argv[2]
private=root/'private/runtime';init=json.loads((private/'initialized.json').read_text());secrets=json.loads((private/'credentials.json').read_text())
env=dict(os.environ,GOMAXPROCS='2',GOFLAGS='-p=2',GOMEMLIMIT='1536MiB',GOTOOLCHAIN='local',GOMODCACHE='/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-mod',GOCACHE='/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-build')
env['NETWORK_TEST_ADMIN_DSN']='postgres://postgres:'+secrets['postgres_password']+'@127.0.0.1:'+str(init['port'])+'/postgres?sslmode=disable'
cmd=['go','test','-count=1','-timeout=3m','-v',*sys.argv[3:],'./internal/data']
at=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
(root/(label+'.json')).write_text(json.dumps({'started_at':at,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'source':str(source),'exit':r.returncode,'database_scope':'fresh testenv databases in this run owned PG; runtime database not used by tests'},indent=2)+'\n')
print(json.dumps({'label':label,'exit':r.returncode}))
print((root/(label+'.log')).read_text()[-6500:])
raise SystemExit(r.returncode)
