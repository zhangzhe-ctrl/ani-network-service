import datetime,hashlib,json,os,pathlib,shutil,subprocess,time
root=pathlib.Path('/home/chabking/workspace/ani-network-service-runs/base-diag-20260917T1437')
r=root/'private/runtime';os.chdir(r)
assert json.load(open('processes.json'))['state']=='stopped'
assert not (r/'watch-capture').exists()
manifest=json.loads((root/'green-manifest.json').read_text())
binary=root/'green-bin/network';assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['network_sha256']
assert hashlib.sha256((r/'bin/network').read_bytes()).hexdigest()=='ce47f75578b230b94cf8e3777e701c528b4f4bd9dd9327a329dd2833f6878c8f'
shutil.copy2(r/'bin/network',r/'bin/network-diagnostic');shutil.copy2(binary,r/'bin/network')
p=json.load(open('plan.json'));p['binary_sha256']['network']=manifest['network_sha256'];p['candidate_source_manifest_sha256']=hashlib.sha256((root/'green-manifest.json').read_bytes()).hexdigest();p['purpose']='Same objects and PG, bounded confirmation of Egress audit retry repair; no diagnostic logging.'
pathlib.Path('plan.json').write_text(json.dumps(p,indent=2)+'\n')
started=datetime.datetime.now(datetime.timezone.utc)
with open('logs/supervisor-green.log','w') as log:
 wrapper=subprocess.Popen(['systemd-run','--user','--scope','--quiet','-p','CPUQuota=200%','-p','MemoryMax=2300M','-p','MemorySwapMax=0','env','GOMAXPROCS=2',str(root/'green-source/scripts/net05a-resource-guard'),'python3','live-runtime.py','serve','--directory',str(r)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
warmup=[];vpc=json.load(open('product-driver/state.json'))['resources']['vpc']['id']
ready=False
for _ in range(90):
 body=json.dumps({'tenant_id':p['tenant_id'],'vpc_id':vpc})
 call=subprocess.run(['./bin/lb-api','call','-target','unix://'+p['sockets']+'/tenant-a.sock','-service','NetworkService','-method','GetVPC'],input=body,capture_output=True,text=True,timeout=5)
 row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':call.returncode,'stdout':call.stdout,'stderr':call.stderr};warmup.append(row)
 pathlib.Path('fixed-warmup.json').write_text(json.dumps({'started_at':started.isoformat(),'samples':warmup},indent=2)+'\n')
 if call.returncode==0:
  v=json.loads(call.stdout)['response']['vpc'];b=v['base_connectivity']
  observed=datetime.datetime.fromisoformat(b['observed_at'].replace('Z','+00:00')) if b.get('observed_at') else None
  ready=v['state']=='RESOURCE_STATE_AVAILABLE' and b['state']=='ready' and not b['observation_stale'] and observed and observed>=started
  if ready:break
 if wrapper.poll() is not None:raise RuntimeError('fixed runtime stopped; inspect own logs')
 time.sleep(1)
assert ready,'no fresh post-restart readiness within warmup window'
ps=json.load(open('processes.json'));network=next(x['pid'] for x in ps['processes'] if x['name']=='network');parent=pathlib.Path('/proc',str(network),'stat').read_text().split()[3];pathlib.Path('supervisor.pid').write_text(parent)
with open('logs/collector.log','w') as log:
 child=subprocess.Popen(['python3','collect.py'],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
pathlib.Path('collector.pid').write_text(str(child.pid))
result={'started_at':started.isoformat(),'fresh_ready_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_sha256':manifest['network_sha256'],'collector_pid':child.pid,'same_vpc_id':vpc,'same_database':p['database'],'guard_wrapper_pid':wrapper.pid}
pathlib.Path('fixed-start.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
