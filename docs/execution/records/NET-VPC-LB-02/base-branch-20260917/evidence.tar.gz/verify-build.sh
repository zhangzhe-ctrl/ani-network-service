set -Eeuo pipefail
TASK_RUN=/home/chabking/workspace/ani-network-service-runs/base-diag-20260917T1437
export GOMAXPROCS=2 GOFLAGS=-p=2 GOMEMLIMIT=1536MiB GOTOOLCHAIN=local
export GOMODCACHE=/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-mod
export GOCACHE=/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-build
cd "$TASK_RUN/green-source"
mkdir -p .tools/bin ../green-bin
cp /home/chabking/workspace/ani-network-service-runs/lb-health-port-20260917T1105/tools/{buf,sqlc} .tools/bin/
git init -q
git add .
make verify > ../verify-green.log 2>&1
go build -o ../green-bin/network ./cmd/ani-network-service
python3 - <<'PY'
import hashlib,json,pathlib,subprocess,datetime
root=pathlib.Path.cwd();files=[]
for n in subprocess.check_output(['git','ls-files','-z']).decode().split('\0'):
 if n:files.append({'path':n,'sha256':hashlib.sha256((root/n).read_bytes()).hexdigest()})
(root.parent/'green-manifest.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files,'network_sha256':hashlib.sha256((root.parent/'green-bin/network').read_bytes()).hexdigest(),'make_verify':'pass'},indent=2)+'\n')
print('verified and built repair candidate')
PY
