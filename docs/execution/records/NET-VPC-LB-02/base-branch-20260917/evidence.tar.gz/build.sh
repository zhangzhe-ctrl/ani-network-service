set -Eeuo pipefail
TASK_RUN=/home/chabking/workspace/ani-network-service-runs/base-diag-20260917T1437
export GOMAXPROCS=2 GOFLAGS=-p=2 GOMEMLIMIT=1536MiB GOTOOLCHAIN=local
export GOMODCACHE=/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-mod
export GOCACHE=/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-build
cd "$TASK_RUN/source"
go version
gofmt -w internal/data/kc_egress.go internal/data/kc_observation.go internal/data/kc_egress_debug.go
go build -o "$TASK_RUN/private/runtime/bin/network" ./cmd/ani-network-service
python3 - <<'PY'
import hashlib,json,pathlib
r=pathlib.Path('/home/chabking/workspace/ani-network-service-runs/base-diag-20260917T1437')
files=json.loads((r/'snapshot.json').read_text())['files']
for f in files:f['effective_sha256']=hashlib.sha256((r/'source'/f['path']).read_bytes()).hexdigest()
(r/'effective-source.json').write_text(json.dumps(files,indent=2)+'\n')
p=r/'private/runtime/plan.json';d=json.loads(p.read_text());d['binary_sha256']={k:hashlib.sha256((r/'private/runtime/bin'/k).read_bytes()).hexdigest() for k in ['network','lb-api']};p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'diagnostic_binary':d['binary_sha256']}))
PY
