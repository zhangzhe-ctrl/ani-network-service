#!/usr/bin/env bash
set -Eeuo pipefail
TASK_RUN=/home/chabking/workspace/ani-network-service-runs/lb-fix-20260918T0011
exec 9>/home/chabking/workspace/ani-network-service-runs/net05a-heavy.lock
flock -n 9 || exit 73
export GOMAXPROCS=2 GOFLAGS=-p=2 GOMEMLIMIT=1536MiB GOTOOLCHAIN=local
export GOMODCACHE=/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-mod
export GOCACHE=/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-build
cd "$TASK_RUN/budget-source"
mkdir -p .tools/bin
cp /home/chabking/workspace/ani-network-service-runs/lb-health-port-20260917T1105/tools/{buf,sqlc} .tools/bin/
git init -q
git add .
make -n integration race > "$TASK_RUN/budget-commands.txt"
set +e
make verify > "$TASK_RUN/verify-budget.log" 2>&1
code=$?
set -e
printf '%s\n' "$code" > "$TASK_RUN/verify-budget.exit"
printf 'make verify exit=%s\n' "$code"
exit "$code"
