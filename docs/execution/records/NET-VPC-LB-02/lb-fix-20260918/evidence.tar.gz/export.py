import pathlib, json, hashlib, re, subprocess, tarfile, shutil, datetime
root=pathlib.Path('/home/chabking/workspace/ani-network-service-runs/lb-fix-20260918T0011')
out=root/'evidence-export';out.mkdir(exist_ok=True)
labels=['receipt-red','receipt-utc-red','retry-red','green-race','verify']
for label in labels:
 for suffix in ('.log','.exit','.toolchain.txt'):
  p=root/(label+suffix)
  if p.exists():shutil.copy2(p,out/p.name)
assert (root/'green-race.exit').read_text().strip()=='0'
assert (root/'verify.exit').read_text().strip()=='0'
for n in ['test.sh','verify.sh','candidate-manifest.json','receipt-probe.go','repair.patch']:
 shutil.copy2(root/n,out/n)
for n in ['kc_load_balancer.go','load_balancer_lifecycle_integration_test.go','load_balancer_process_integration_test.go','lb_audit_retry_integration_test.go']:
 shutil.copy2(root/'green-source/internal/data'/n,out/n)
shutil.copy2(root/'red-source/internal/data/lb_audit_retry_integration_test.go',out/'red-test.go')
manifest=json.loads((root/'candidate-manifest.json').read_text())
effective=[]
for f in manifest['files']:
 p=root/'green-source'/f['path']
 effective.append({'path':f['path'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(root/'effective-source.json').write_text(json.dumps({'base_head':manifest['head'],'files':effective},indent=2)+'\n')
shutil.copy2(root/'effective-source.json',out/'effective-source.json')
containers=[]
for label in labels:
 for cid in re.findall(r'PostgreSQL image=\S+ container=([a-f0-9]{64})',(root/(label+'.log')).read_text()):
  result=subprocess.run(['docker','inspect',cid],capture_output=True,text=True)
  assert result.returncode!=0,cid
  assert 'no such' in result.stderr.lower(),result.stderr
  containers.append({'label':label,'id':cid,'removed':True})
s=(root/'green-race.log').read_text()
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_head':manifest['head'],'run':str(root),'host':'fedora','go':(root/'green-race.toolchain.txt').read_text().strip(),'timezone':'UTC for CI red and green race', 'gates':{'original_receipt_default_timezone':'pass (private and public_private)', 'original_receipt_utc':'expected_red: all three exposure cases; only equal-instant location differences','original_lb_retry':'expected_red: both private and public_private', 'lb_and_related_pg_race':'pass','make_verify':'pass','ci_after_push':'not_verified_at_record_creation','live_product_dual_lb_stability':'not_verified_this_turn'},'race_top_level_passes':len(re.findall(r'^--- PASS:',s,re.M)),'race_subtest_passes':len(re.findall(r'^ +--- PASS:',s,re.M)),'configured_measurements':[line.strip() for line in s.splitlines() if 'configured/fresh after' in line],'containers':containers,'cluster_writes':False}
(root/'gates.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
shutil.copy2(root/'gates.json',out/'gates.json')
print(json.dumps({'top_level':summary['race_top_level_passes'],'subtests':summary['race_subtest_passes'],'removed_containers':len(containers)}))
