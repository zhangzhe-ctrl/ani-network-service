#!/usr/bin/env bash
set -Eeuo pipefail
TASK_RUN=/home/chabking/workspace/ani-network-service-runs/lb-fix-20260918T0011
cd "$TASK_RUN"
exec 9>/home/chabking/workspace/ani-network-service-runs/net05a-heavy.lock
flock -n 9 || exit 73
python3 - <<'PY'
import os,shutil,pathlib
assert os.getloadavg()[0]<6
assert shutil.disk_usage('.').free>20*1024**3
m=dict((a,b.split()[0]) for a,b in (l.split(':',1) for l in pathlib.Path('/proc/meminfo').read_text().splitlines()))
assert int(m['MemAvailable'])>5*1024**2
print('resource preflight pass')
PY
label=${1:?label}
source=${2:?source}
pattern=${3:?pattern}
shift 3
export GOMAXPROCS=2 GOFLAGS=-p=2 GOMEMLIMIT=1536MiB GOTOOLCHAIN=local
export GOMODCACHE=/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-mod
export GOCACHE=/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-build
cd "$source"
go version > "$TASK_RUN/$label.toolchain.txt"
set +e
scripts/integration -timeout 12m -run "$pattern" -v "$@" ./internal/data > "$TASK_RUN/$label.log" 2>&1
code=$?
set -e
printf '%s\n' "$code" > "$TASK_RUN/$label.exit"
printf '%s exit=%s\n' "$label" "$code"
exit "$code"
