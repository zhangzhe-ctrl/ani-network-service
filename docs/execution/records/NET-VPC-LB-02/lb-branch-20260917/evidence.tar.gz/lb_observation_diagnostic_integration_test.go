package data_test

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/google/uuid"
	"github.com/zhangzhe-ctrl/ani-network-service/internal/biz"
	"github.com/zhangzhe-ctrl/ani-network-service/internal/data"
	controlled "github.com/zhangzhe-ctrl/ani-network-service/tests/net05a/provider"
	"k8s.io/client-go/tools/clientcmd"
)

// This diagnostic records a symmetric controlled fault, not a regression claim
// about the historical private/public_private difference. Setup uses the existing
// product lifecycle fixture; the measured step uses the original runtime budgets.
// It never changes Provider conditions, identity checks, or production decisions.
type lbObservationDiagnosticTransport struct{ next http.RoundTripper }

func (t lbObservationDiagnosticTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	copy := r.Clone(r.Context())
	copy.Header = r.Header.Clone()
	copy.Header.Set("X-NET-LB-OBS-01", "boundary-diagnostic")
	return t.next.RoundTrip(copy)
}

type lbObservationDiagnosticProvider struct {
	*data.KCProvider
	observation                 biz.LoadBalancerObservation
	err                         error
	started, finished, deadline time.Time
}

// Claim's production alternation can select platform work even when the target
// LB is oldest in the tenant lane. This fixture isolates that lane selection
// from the observation experiment. Every lease still comes from real PG; other
// fixture-only leases remain unprocessed until the test database is removed.
// Scheduler fairness, capacity, and recovery of those skipped jobs are not tested.
type lbObservationDiagnosticRepository struct {
	*data.Postgres
	target  string
	skipped []map[string]any
}

func (r *lbObservationDiagnosticRepository) Claim(ctx context.Context, owner string, lease time.Duration) (biz.Work, bool, error) {
	for attempt := 0; attempt < 32; attempt++ {
		work, found, err := r.Postgres.Claim(ctx, owner, lease)
		if err != nil || !found || work.Resource.ID == r.target {
			return work, found, err
		}
		r.skipped = append(r.skipped, map[string]any{"id": work.Resource.ID, "kind": work.Resource.Kind, "epoch": work.Epoch, "claimed_at": work.Now})
	}
	return biz.Work{}, false, fmt.Errorf("diagnostic target %s not selected within 32 real Claims", r.target)
}

func (p *lbObservationDiagnosticProvider) ObserveLoadBalancer(ctx context.Context, w biz.Work) (biz.LoadBalancerObservation, error) {
	p.started = time.Now()
	p.deadline, _ = ctx.Deadline()
	p.observation, p.err = p.KCProvider.ObserveLoadBalancer(ctx, w)
	p.finished = time.Now()
	return p.observation, p.err
}

func lbObservationDiagnosticObjects(api *controlled.Server) string {
	api.Backend.Mu.Lock()
	defer api.Backend.Mu.Unlock()
	body, _ := json.Marshal(api.Backend.Objects)
	sum := sha256.Sum256(body)
	return hex.EncodeToString(sum[:])
}

func TestLBObservationDiagnosticConsecutiveWatchBoundaries(t *testing.T) {
	for _, exposure := range []string{"private", "public_private"} {
		t.Run(exposure, func(t *testing.T) {
			type watchSession struct {
				ctx    context.Context
				cancel context.CancelFunc
			}
			var observer atomic.Pointer[data.KCObservation]
			var armed, captured atomic.Bool
			var boundaries atomic.Int32
			var mu sync.Mutex
			active := map[*watchSession]bool{}
			controller := &lbControllerFixture{}
			f := newLBAdmissionFixture(t, func(w http.ResponseWriter, r *http.Request, api *controlled.Server) bool {
				if strings.HasSuffix(r.URL.Path, "/subjectaccessreviews") && r.Method == http.MethodPost {
					var request map[string]any
					if json.NewDecoder(r.Body).Decode(&request) != nil {
						http.Error(w, "invalid review", http.StatusBadRequest)
						return true
					}
					request["status"] = map[string]any{"allowed": true}
					w.Header().Set("Content-Type", "application/json")
					_ = json.NewEncoder(w).Encode(request)
					return true
				}
				if r.Header.Get("X-NET-LB-OBS-01") != "boundary-diagnostic" {
					return controller.http(w, r, api)
				}
				if r.URL.Query().Get("watch") == "true" && strings.HasSuffix(r.URL.Path, "/pods") {
					ctx, cancel := context.WithCancel(r.Context())
					session := &watchSession{ctx, cancel}
					mu.Lock()
					active[session] = true
					mu.Unlock()
					defer func() { cancel(); mu.Lock(); delete(active, session); mu.Unlock() }()
					api.ServeHTTP(w, r.WithContext(ctx))
					return true
				}
				if !armed.Load() || r.Method != http.MethodGet || !strings.HasSuffix(r.URL.Path, "/eips") || r.URL.Query().Get("watch") == "true" || r.URL.Query().Get("resourceVersion") != "" || !captured.CompareAndSwap(false, true) {
					return controller.http(w, r, api)
				}
				response := httptest.NewRecorder()
				api.ServeHTTP(response, r)
				ticker := time.NewTicker(time.Millisecond)
				defer ticker.Stop()
				// Two actual renewals while this one complete LIST remains in flight.
				// Waiting on observed boundaries avoids a guessed sleep duration.
				for i := 0; i < 2; i++ {
					var session *watchSession
					for session == nil {
						mu.Lock()
						for candidate := range active {
							if candidate.ctx.Err() == nil {
								session = candidate
								break
							}
						}
						mu.Unlock()
						if session != nil {
							break
						}
						select {
						case <-ticker.C:
						case <-r.Context().Done():
							return true
						}
					}
					before := observer.Load().Snapshot()["source_boundaries_total"]
					session.cancel()
					for observer.Load().Snapshot()["source_boundaries_total"] <= before {
						select {
						case <-ticker.C:
						case <-r.Context().Done():
							return true
						}
					}
					boundaries.Add(1)
				}
				for key, values := range response.Header() {
					w.Header()[key] = values
				}
				w.WriteHeader(response.Code)
				_, _ = w.Write(response.Body.Bytes())
				return true
			})
			request := f.request
			request.Exposure = exposure
			if exposure == "public_private" {
				request.PublicEIPID = f.f.eip(t, "diagnostic-entry").ID
			}
			created, err := f.lbs.Create(f.f.ctx, request)
			if err != nil {
				t.Fatal(err)
			}
			initial := lbState(t, f, created.LoadBalancer.ID, biz.Available)
			if initial.ConfigurationState != "configured" {
				t.Fatal("lifecycle precondition", initial)
			}

			expected := seedLBInstallation(f.api)
			config, err := clientcmd.BuildConfigFromFlags("", f.kubeconfig)
			if err != nil {
				t.Fatal(err)
			}
			config.QPS, config.Burst = 10, 20
			config.WrapTransport = func(rt http.RoundTripper) http.RoundTripper { return lbObservationDiagnosticTransport{rt} }
			provider, err := data.NewKCProvider(f.f.p, config)
			if err != nil {
				t.Fatal(err)
			}
			if err = provider.ConfigureLoadBalancer(expected); err != nil {
				t.Fatal(err)
			}
			options := data.DefaultObservationOptions()
			options.AuditInterval, options.AuditJitter, options.AuditTimeout = 15*time.Second, time.Second, 15*time.Second
			obs, err := provider.EnableObservation(options)
			if err != nil {
				t.Fatal(err)
			}
			observer.Store(obs)
			ctx, cancel := context.WithCancel(f.f.ctx)
			done := make(chan error, 1)
			go func() { done <- obs.Start(ctx) }()
			t.Cleanup(func() {
				cancel()
				if err := <-done; err != nil {
					t.Error(err)
				}
			})
			// Startup Watch boundaries can invalidate the immediate first audit.
			// Allow that bounded collection, the configured next interval/jitter,
			// and one further collection. This initializes the fixture only; it
			// does not extend either the measured request or the fault window.
			initializationBudget := 2*options.AuditTimeout + options.AuditInterval + options.AuditJitter + options.FlushInterval
			initializationCtx, stopInitialization := context.WithTimeout(f.f.ctx, initializationBudget)
			defer stopInitialization()
			initializationTicker := time.NewTicker(25 * time.Millisecond)
			defer initializationTicker.Stop()
			for {
				var ready bool
				if f.f.owner.QueryRow(initializationCtx, `SELECT ready FROM network_lb_capabilities WHERE cluster_id='test-cluster' AND fingerprint=$1`, expected.Fingerprint).Scan(&ready) == nil && ready && obs.Snapshot()["source_boundaries_total"] >= 24 {
					break
				}
				select {
				case <-initializationTicker.C:
				case <-initializationCtx.Done():
					var capability string
					diagnosticCtx, stopDiagnostic := context.WithTimeout(f.f.ctx, time.Second)
					capabilityErr := f.f.owner.QueryRow(diagnosticCtx, `SELECT to_jsonb(c)::text FROM network_lb_capabilities c WHERE cluster_id='test-cluster'`).Scan(&capability)
					stopDiagnostic()
					requests, bytes := f.api.Counts()
					t.Fatalf("NET-LB-OBS-01 initialization expired: budget=%s capability=%s capability_error=%v observer=%v api_requests=%v api_bytes=%v", initializationBudget, capability, capabilityErr, obs.Snapshot(), requests, bytes)
				}
			}
			stopInitialization()
			probe := &lbObservationDiagnosticProvider{KCProvider: provider}
			policy := biz.DefaultWorkerPolicy()
			policy.Lease, policy.RequestTimeout, policy.ObserveEvery, policy.StaleAfter = 120*time.Second, 30*time.Second, 5*time.Second, 60*time.Second
			// The live runner used 30s; DefaultWorkerPolicy/config.yaml use 60s.
			// Record the actual policy below rather than implying all defaults match.
			policy.RetryMax = 30 * time.Second
			var finishedWork biz.Work
			var finishedProgress biz.Progress
			var finishError error
			repository := &lbObservationDiagnosticRepository{Postgres: f.f.p, target: initial.ID}
			worker, err := biz.NewWorker(repository, probe, uuid.NewString(), policy, func(_ context.Context, w biz.Work, p biz.Progress, err error) {
				finishedWork, finishedProgress, finishError = w, p, err
			})
			if err != nil {
				t.Fatal(err)
			}
			step := func() {
				// Scheduling only: no SQL writes to health, identity, or proof data.
				if _, err := f.f.owner.Exec(f.f.ctx, `UPDATE network_reconciliations SET next_run_at=clock_timestamp()-interval '1 hour' WHERE tenant_id=$1 AND lb_id=$2`, f.f.tenant, initial.ID); err != nil {
					t.Fatal(err)
				}
				if worked, err := worker.Step(f.f.ctx); err != nil || !worked {
					t.Fatalf("step: worked=%v err=%v", worked, err)
				}
				if finishedWork.Resource.ID != initial.ID {
					t.Fatalf("wrong work selected: %s", finishedWork.Resource.ID)
				}
			}
			step()
			baseline, err := f.lbs.Get(f.f.ctx, "", initial.ID)
			if err != nil || probe.err != nil || baseline.ConfigurationState != "configured" || baseline.ObservationStale {
				t.Fatalf("measured-provider precondition: lb=%+v adapter=%v read=%v", baseline, probe.err, err)
			}
			beforeNotifications := obs.Snapshot()["notifications_total"]
			pod := f.api.Object("pods", "tenant-"+f.f.tenant, "lb-backend")
			metadata := pod["metadata"].(map[string]any)
			annotations, _ := metadata["annotations"].(map[string]any)
			if annotations == nil {
				annotations = map[string]any{}
				metadata["annotations"] = annotations
			}
			annotations["net-lb-obs-01"] = "boundary-trigger"
			f.api.Change("pods", pod, false)
			awaitNET05A(t, 3*time.Second, func() bool { return obs.Snapshot()["notifications_total"] > beforeNotifications })
			factsBefore := lbObservationDiagnosticObjects(f.api)
			metricsBefore := obs.Snapshot()
			armed.Store(true)
			step() // The only faulted attempt; no retry-until-green assertion.
			armed.Store(false)
			actual, err := f.lbs.Get(f.f.ctx, "", initial.ID)
			if err != nil {
				t.Fatal(err)
			}
			var reconciliation string
			if err = f.f.owner.QueryRow(f.f.ctx, `SELECT json_build_object('requested_generation',requested_generation,'processed_generation',processed_generation,'evidence_applied_at',evidence_applied_at,'next_run_at',next_run_at,'retry_not_before',retry_not_before,'lease_epoch',lease_epoch,'db_now',clock_timestamp())::text FROM network_reconciliations WHERE tenant_id=$1 AND lb_id=$2`, f.f.tenant, initial.ID).Scan(&reconciliation); err != nil {
				t.Fatal(err)
			}
			causes := []string{}
			for cause := probe.err; cause != nil; cause = errors.Unwrap(cause) {
				causes = append(causes, cause.Error())
			}
			body, err := json.Marshal(map[string]any{
				"exposure": exposure, "lb_id": initial.ID, "phase": "single_faulted_worker_step",
				"worker_policy": policy, "observation_options": options, "kubernetes_qps": config.QPS, "kubernetes_burst": config.Burst,
				"initialization_budget": initializationBudget.String(), "worker_concurrency": 1,
				"skipped_fixture_claims": repository.skipped, "scheduler_under_test": false,
				"work": finishedWork, "progress": finishedProgress, "finish_error": finishError,
				"adapter_started": probe.started, "adapter_finished": probe.finished, "request_deadline": probe.deadline,
				"adapter_causes": causes, "adapter_observation": probe.observation,
				"baseline": baseline, "result": actual, "reconciliation": json.RawMessage(reconciliation),
				"metrics_before": metricsBefore, "metrics_after": obs.Snapshot(),
				"injected_boundaries": boundaries.Load(), "provider_facts_sha256_before": factsBefore,
				"provider_facts_sha256_after": lbObservationDiagnosticObjects(f.api),
			})
			if err != nil {
				t.Fatal(err)
			}
			t.Logf("NET-LB-OBS-01 %s", body)
			if !captured.Load() || boundaries.Load() != 2 {
				t.Fatalf("trigger not covered: captured=%v boundaries=%d", captured.Load(), boundaries.Load())
			}
			if factsBefore != lbObservationDiagnosticObjects(f.api) {
				t.Fatal("Provider facts changed during the controlled boundary-only attempt")
			}
			if finishError != nil {
				t.Fatalf("Finish failed: %v", finishError)
			}
			if probe.finished.After(probe.deadline.Add(time.Second)) {
				t.Fatal("adapter exceeded caller deadline")
			}
			if actual.ConfigurationState != "configured" || actual.ObservationStale || probe.err != nil {
				t.Fatalf("NET-LB-OBS-RED stable CR facts degraded: exposure=%s state=%s reason=%s stale=%v elapsed=%s remaining=%s error=%v", exposure, actual.ConfigurationState, actual.Reason, actual.ObservationStale, probe.finished.Sub(probe.started), probe.deadline.Sub(probe.finished), probe.err)
			}
		})
	}
}
