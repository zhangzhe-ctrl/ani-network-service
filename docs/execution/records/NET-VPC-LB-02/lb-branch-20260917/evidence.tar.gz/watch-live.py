import datetime, hashlib, json, os, pathlib, subprocess, threading, time
root = pathlib.Path('/tmp/codex-lb-obs-20260917T1538-r2')
root.mkdir(mode=0o700, exist_ok=True)
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def project(o):
    m=o.get('metadata', {})
    d={'kind':o.get('kind'),'metadata':{k:m.get(k) for k in ['namespace','name','uid','generation','resourceVersion','deletionTimestamp']},'status':o.get('status')}
    if o.get('kind') not in ['Pod']: d['spec']=o.get('spec')
    return d
targets=[('pubdebug-20260917',k) for k in ['gateways','httproutes','backends','backendtrafficpolicies','services','pods','vpcs','eips','snats','vnics','vnicips']]+[('kcn-system','subnets')]
deadline=time.monotonic()+600
def watch(ns,kind):
    out=root/(ns+'-'+kind+'.jsonl')
    with out.open('w') as f:
        def record(v): f.write(json.dumps({'at':now(),**v},separators=(',',':'))+'\n');f.flush()
        args=['kubectl','get',kind,'-n',ns,'-o','json']
        r=subprocess.run(args,capture_output=True,text=True,timeout=30)
        if r.returncode: record({'record':'error','stderr':r.stderr});return
        initial=json.loads(r.stdout);record({'record':'initial','objects':[project(x) for x in initial['items']]})
        with (root/(ns+'-'+kind+'.stderr')).open('w') as err:
            p=subprocess.Popen(args+['--watch','--output-watch-events'],stdout=subprocess.PIPE,stderr=err,text=True,bufsize=1)
            timer=threading.Timer(max(0,deadline-time.monotonic()),p.terminate);timer.start()
            record({'record':'watch_start','pid':p.pid})
            buffer='';decoder=json.JSONDecoder()
            try:
                for line in p.stdout:
                    buffer+=line
                    while buffer.strip():
                        try: value,end=decoder.raw_decode(buffer.lstrip())
                        except json.JSONDecodeError:break
                        buffer=buffer.lstrip()[end:]
                        record({'record':'event','type':value.get('type'),'object':project(value.get('object',{}))})
                p.wait(timeout=5)
            finally: timer.cancel()
            record({'record':'watch_end','exit':p.returncode,'window_ended':time.monotonic()>=deadline,'unparsed_bytes':len(buffer.strip())})
(root/'lifecycle.json').write_text(json.dumps({'start':now(),'pid':os.getpid(),'seconds':600,'mode':'read-only existing manual scene; no Network database belongs to these CRs'},indent=2))
threads=[threading.Thread(target=watch,args=x) for x in targets]
for t in threads:t.start()
for t in threads:t.join()
(root/'completed.json').write_text(json.dumps({'completed':now(),'files':len(list(root.glob('*.jsonl')))},indent=2))
