#!/usr/bin/env bash
set -Eeuo pipefail
TASK_RUN=/home/chabking/workspace/ani-network-service-runs/lb-diag-20260917T1538
cd "$TASK_RUN"
exec 9>/home/chabking/workspace/ani-network-service-runs/net05a-heavy.lock
flock -n 9 || exit 73
python3 - <<'PY'
import hashlib,json,pathlib,os,shutil,tarfile
r=pathlib.Path('.');m=json.load(open('source-manifest.json'))
assert os.getloadavg()[0]<6
assert shutil.disk_usage(r).free>20*1024**3
mem=dict((a,b.split()[0]) for a,b in (line.split(':',1) for line in pathlib.Path('/proc/meminfo').read_text().splitlines()))
assert int(mem['MemAvailable'])>5*1024**2
if not (r/'source').exists():
 assert hashlib.sha256((r/'source.tar.gz').read_bytes()).hexdigest()==m['archive_sha256']
 (r/'source').mkdir()
 with tarfile.open(r/'source.tar.gz') as t:t.extractall(r/'source',filter='data')
 for x in m['files']:assert hashlib.sha256((r/'source'/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
print('preflight and source verification pass')
PY
label=${1:?label}
export GOMAXPROCS=2 GOFLAGS=-p=2 GOMEMLIMIT=1536MiB GOTOOLCHAIN=local
export GOMODCACHE=/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-mod
export GOCACHE=/home/chabking/workspace/ani-network-service-runs/net-lb-obs-01-20260916T005807Z-baseline/cache/go-build
cd "$TASK_RUN/${2:-source}"
go version > "$TASK_RUN/$label.toolchain.txt"
gofmt -w internal/data/lb_observation_diagnostic_integration_test.go internal/data/kc_load_balancer.go
if [[ -f internal/data/kc_lb_diagnostic.go ]]; then gofmt -w internal/data/kc_lb_diagnostic.go; fi
set +e
scripts/integration -timeout 4m -run '^TestLBObservationDiagnosticConsecutiveWatchBoundaries$' -v ./internal/data > "$TASK_RUN/$label.log" 2>&1
code=$?
set -e
printf '%s\n' "$code" > "$TASK_RUN/$label.exit"
printf 'diagnostic %s exit=%s\n' "$label" "$code"
exit "$code"
