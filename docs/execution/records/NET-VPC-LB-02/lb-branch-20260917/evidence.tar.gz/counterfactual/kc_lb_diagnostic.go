package data

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/zhangzhe-ctrl/ani-network-service/internal/biz"
	"os"
	"time"
)

func (p *KCProvider) lbDiagnostic(ctx context.Context, w biz.Work, refresh bool, started time.Time, v *auditView, keys []string, proof biz.ObservationProof, dependencies bool, branch string) {
	deadline, _ := ctx.Deadline()
	p.observation.mu.Lock()
	changed := map[string]uint64{}
	for _, key := range keys {
		if n := p.observation.changes[key]; n > v.sequence {
			changed[key] = n
		}
	}
	value := map[string]any{"at": time.Now().UTC(), "branch": branch, "lb": w.Resource.ID, "exposure": w.Resource.LoadBalancer.LoadBalancer.Exposure, "refresh": refresh, "elapsed_ms": time.Since(started).Milliseconds(), "remaining_ms": time.Until(deadline).Milliseconds(), "proof_covers": proof.Covers(w.Requirement), "proof": proof, "requirement": w.Requirement, "view_epoch": v.epoch, "current_epoch": p.observation.epoch, "view_sequence": v.sequence, "current_sequence": p.observation.sequence, "changed_keys": changed, "dependencies_ready": dependencies}
	p.observation.mu.Unlock()
	body, _ := json.Marshal(value)
	fmt.Fprintf(os.Stderr, "[DEBUG-lb0917] %s\n", body)
}
